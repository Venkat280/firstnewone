# Security Policy

## Supported Versions

Only the current release has all fixes. There are no backports to older releases.

## Reporting a Vulnerability

E-mail secalert_us@oracle.com
